export interface IWeatherData {
  temperature: number;
  humidity: number;
  pressure: number;
}
