Weather application currently shows the weather data in main display area. We need to update `displayOne`, `displayTwo`, and `displayThree` so that they can display the weather data in their own way. Please refer to the comment in respective function.

`measurementsChanged` method in `WeatherData` class gets called whenever the weather data changes.
